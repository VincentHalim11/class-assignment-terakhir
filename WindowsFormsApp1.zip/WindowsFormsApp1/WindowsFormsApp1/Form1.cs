﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        MySqlConnection connection;
        MySqlCommand command;
        MySqlDataAdapter adapter;
        DataTable dt = new DataTable();
        DataTable dt2 = new DataTable();
        string kueri;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            connection = new MySqlConnection("server = localhost;uid = root; pwd = isbmantap;database = premier_league");
            connection.Open();
            connection.Close();
           
            kueri = "select team_name,team_id from team;";
            command = new MySqlCommand(kueri,connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(dt);
            adapter.Fill(dt2);
            cb_home.DataSource = dt;
            cb_home.DisplayMember = "team_name";
            cb_home.ValueMember = "team_id";

            cb_away.DataSource = dt2;
            cb_away.DisplayMember = "team_name";
            cb_away.ValueMember = "team_id";

            
           


        }

        private void cb_home_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable cpthome = new DataTable();
            DataTable manager = new DataTable();
            DataTable stadion = new DataTable();
            DataTable capacity = new DataTable();
            
            string query = $"select player_name from player,team where player.player_id = team.captain_id && player.team_id = '{cb_home.SelectedValue}';";
            command = new MySqlCommand(query,connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(cpthome);
            if(cpthome.Rows.Count != 0)
            {
                lbl_captainhome.Text = cpthome.Rows[0][0].ToString();
            }

            string query2 = $"select manager_name from manager,team where manager.manager_id = team.manager_id && team.team_id = '{cb_home.SelectedValue}'";
            command = new MySqlCommand(query2,connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(manager);
            if(manager.Rows.Count != 0)
            {
                lbl_manager1.Text = manager.Rows[0][0].ToString();
            }

            string query3 = $"select home_stadium from team where team_id = '{cb_home.SelectedValue}'";
            command = new MySqlCommand(query3, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(stadion);
            if (stadion.Rows.Count != 0)
            {
                lbl_stadion.Text = stadion.Rows[0][0].ToString();
            }

            string query4 = $"select capacity from team where team_id = '{cb_home.SelectedValue}'";
            command = new MySqlCommand(query4, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(capacity);
            if (capacity.Rows.Count != 0)
            {
                lbl_cap.Text = capacity.Rows[0][0].ToString();
            }

        }

        private void cb_away_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable cptaway = new DataTable();
            DataTable manager = new DataTable();

            string query = $"select player_name from player,team where player.player_id = team.captain_id && player.team_id = '{cb_away.SelectedValue}';";
            command = new MySqlCommand(query, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(cptaway);
            if (cptaway.Rows.Count != 0)
            {
                lbl_cptaway.Text = cptaway.Rows[0][0].ToString();
            }

            string query2 = $"select manager_name from manager,team where manager.manager_id = team.manager_id && team.team_id = '{cb_away.SelectedValue}'";
            command = new MySqlCommand(query2, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(manager);
            if (manager.Rows.Count != 0)
            {
                lbl_manager2.Text = manager.Rows[0][0].ToString();
            }
        }

        private void btn_cek_Click(object sender, EventArgs e)
        {
            DataTable date = new DataTable();
            DataTable skor = new DataTable();
            DataTable skor2 = new DataTable();
            string tanggal = $"select concat(day(match_date), ' ', date_format(match_date, '%M'), ' ', Year(match_date))  from `match` where team_home = '{cb_home.SelectedValue}' && team_away = '{cb_away.SelectedValue}'";
            command = new MySqlCommand(tanggal, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(date);
            if (date.Rows.Count != 0)
            {
                lbl_tanggal.Text = date.Rows[0][0].ToString();
                
            }

            string skorz = $"select goal_home from `match` where team_home = '{cb_home.SelectedValue}' && team_away = '{cb_away.SelectedValue}'";
            command = new MySqlCommand(skorz, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(skor);
            if (skor.Rows.Count != 0)
            {
                lbl_skorhome.Text = skor.Rows[0][0].ToString();

            }


            string skorzz = $"select goal_away from `match` where team_home = '{cb_home.SelectedValue}' && team_away = '{cb_away.SelectedValue}'";
            command = new MySqlCommand(skorzz, connection);
            adapter = new MySqlDataAdapter(command);
            adapter.Fill(skor2);
            if(skor2.Rows.Count != 0)
            {
                lbl_skoraway.Text = skor2.Rows[0][0].ToString();
            }


        }
    }
}
